from lip_reading.utils import DatasetRecorder

if __name__ == "__main__":

    DatasetRecorder(class_name='bravo',type='train',shape=(120,120),save_original=True)