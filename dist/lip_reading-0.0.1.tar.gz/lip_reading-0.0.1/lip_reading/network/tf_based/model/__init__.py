from lip_reading.network.tf_based.model.resnet_based import RES_BI_LSTM
from lip_reading.network.tf_based.model.vgg_based import VGG_BI_LSTM
