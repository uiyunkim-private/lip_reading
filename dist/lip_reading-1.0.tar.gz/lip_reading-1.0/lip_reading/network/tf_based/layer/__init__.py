from lip_reading.network.tf_based.layer.resnet import ResNet50
from lip_reading.network.tf_based.layer.vggnet import Vggnet